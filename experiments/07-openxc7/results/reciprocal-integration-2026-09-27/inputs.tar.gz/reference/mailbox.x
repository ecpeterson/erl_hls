// Shared-scheduler mailbox storage primitives.
//
// The scheduler owns queue metadata; these pure helpers select and update it.
// Frame payloads live in external RAM at stable, slot-major addresses.
// DEPTH is the actor mailbox capacity (1..255), matching u8 counts and indices.
// Actor and producer arrays are nonempty.

import axis;
import bram;

// One frame plus its phase-local postponement flag.
pub struct Slot {
  postponed: u1,
  frame: axis::Frame,
}

// A pending actor message, or an effect-batch credit when credit is set.
pub struct ScheduledRequest {
  slot: u32,
  frame: axis::Frame,
  credit: u1,
}

// A reserved producer/destination/RAM slot; indices are meaningful only if valid.
pub struct Admission {
  valid: u1,
  producer: u32,
  slot: u32,
  physical: u8,
}

// Whole-row mailbox read request.
pub type RamReadReq = bram::ReadReq;
// One complete mailbox frame returned from RAM.
pub type RamReadResp = bram::ReadResp<axis::FRAME_BITS>;
// Whole-frame mailbox write request.
pub type RamWriteReq = bram::WriteReq<axis::FRAME_BITS>;
// Completion token for a mailbox write.
pub type RamWriteResp = bram::WriteResp;

// Map an actor slot and physical queue index to a slot-major RAM address.
// index must be below capacity; the result must fit u32 and the allocated RAM.
pub fn address(slot: u32, index: u8, capacity: u32) -> u32 {
  slot * capacity + index as u32
}

// Construct a whole-frame read under address's bounds; this does not issue I/O.
pub fn read(slot: u32, index: u8, capacity: u32) -> RamReadReq {
  bram::read(address(slot, index, capacity))
}

// Construct a whole-frame write under address's bounds; this does not issue I/O.
pub fn write(
    slot: u32, index: u8, capacity: u32, frame: axis::Frame)
    -> RamWriteReq {
  bram::write(address(slot, index, capacity), axis::bits_from_frame(frame))
}

// Selectors return zero indices when no candidate exists; callers must use
// the valid flag (or establish spare capacity before calling free_index).
// All order entries are below DEPTH; occupied prefixes are also distinct.
fn free_index<DEPTH: u32>(order: u8[DEPTH], occupied: u8) -> u8 {
  let (_found, selected) = unroll_for! (candidate, acc):
      (u32, (u1, u8)) in
      u32:0..DEPTH {
    let used = unroll_for! (position, found):
        (u32, u1) in u32:0..DEPTH {
      found || (
        position < occupied as u32 &&
        order[position] == candidate as u8)
    }(u1:0);
    let take = !acc.0 && !used;
    (
      acc.0 || take,
      if take { candidate as u8 } else { acc.1 }
    )
  }((u1:0, u8:0));
  selected
}

// Return (valid, logical queue position, physical RAM index), skipping
// postponed messages without changing their order or releasing their slots.
// occupied must not exceed DEPTH; every order entry must be below DEPTH.
// An empty or fully postponed queue returns (false, 0, 0).
pub fn select<DEPTH: u32>(
    order: u8[DEPTH], occupied: u8, postponed: u1[DEPTH]) -> (u1, u8, u8) {
  unroll_for! (position, acc):
      (u32, (u1, u8, u8)) in
      u32:0..DEPTH {
    let physical = order[position];
    let take = !acc.0 &&
      position < occupied as u32 &&
      !postponed[physical as u32];
    (
      acc.0 || take,
      if take { position as u8 } else { acc.1 },
      if take { physical } else { acc.2 }
    )
  }((u1:0, u8:0, u8:0))
}

// Remove one consumed logical position; the remaining physical indices keep
// their order. The caller decrements occupied and owns postponement resets.
// selected must name an occupied position and occupied must not exceed DEPTH.
pub fn compact_order<DEPTH: u32>(
    row: u8[DEPTH],
    selected: u8,
    occupied: u8) -> u8[DEPTH] {
  unroll_for! (position, result):
      (u32, u8[DEPTH]) in
      u32:0..DEPTH {
    let value = if position < selected as u32 {
      row[position]
    } else if position + u32:1 < occupied as u32 {
      row[position + u32:1]
    } else {
      u8:0
    };
    update(result, position, value)
  }(zero!<u8[DEPTH]>())
}

// Returned batch credits represent completed effect batches, so they
// update scheduler metadata without carrying another actor context.
// Select only from the registered inputs. pending_valid also includes newly
// captured requests; preserve those for the next iteration. Registered-valid
// slots cannot be overwritten during capture.
pub fn collect_credit<PRODUCER_COUNT: u32>(
    registered_pending: ScheduledRequest[PRODUCER_COUNT],
    registered_valid: u1[PRODUCER_COUNT],
    pending_valid: u1[PRODUCER_COUNT],
    egress_busy: u1) -> (u1[PRODUCER_COUNT], u1) {
  let (credit_found, credit_producer) =
    unroll_for! (candidate, acc):
        (u32, (u1, u32)) in u32:0..PRODUCER_COUNT {
      let take = !acc.0 && registered_valid[candidate] &&
        registered_pending[candidate].credit;
      (acc.0 || take, if take { candidate } else { acc.1 })
    }((u1:0, u32:0));
  let remaining = if credit_found {
    update(pending_valid, credit_producer, u1:0)
  } else {
    pending_valid
  };
  (remaining, egress_busy && !credit_found)
}

// Each credit returns the named actor's independently reserved outbox after
// its entire batch drains. Collect all registered credits, so a busy producer
// cannot starve another actor's return. Fresh captures wait one activation;
// the caller must issue at most one batch per actor between returns.
pub fn collect_actor_credits<ACTOR_COUNT: u32, PRODUCER_COUNT: u32>(
    registered_pending: ScheduledRequest[PRODUCER_COUNT],
    registered_valid: u1[PRODUCER_COUNT],
    pending_valid: u1[PRODUCER_COUNT],
    outbox_busy: u1[ACTOR_COUNT]) -> (u1[PRODUCER_COUNT], u1[ACTOR_COUNT]) {
  let returned = unroll_for! (slot, result):
      (u32, u1[ACTOR_COUNT]) in u32:0..ACTOR_COUNT {
    let found = unroll_for! (producer, found):
        (u32, u1) in u32:0..PRODUCER_COUNT {
      found || (registered_valid[producer] &&
        registered_pending[producer].credit &&
        registered_pending[producer].slot == slot)
    }(false);
    update(result, slot, outbox_busy[slot] && !found)
  }(zero!<u1[ACTOR_COUNT]>());
  let remaining = unroll_for! (producer, result):
      (u32, u1[PRODUCER_COUNT]) in u32:0..PRODUCER_COUNT {
    let credit = registered_valid[producer] && registered_pending[producer].credit;
    update(result, producer, pending_valid[producer] && !credit)
  }(zero!<u1[PRODUCER_COUNT]>());
  (remaining, returned)
}

// Credits neither consume messages nor release a different actor's slot.
#[test]
fn actor_credits_are_independent_and_registered_test() {
  let request = zero!<ScheduledRequest>();
  let pending = [ScheduledRequest {slot: u32:2, credit: true, ..request},
    request, ScheduledRequest {slot: u32:0, credit: true, ..request}];
  assert_eq(collect_actor_credits(pending, [false, true, true],
    [true, true, true], [true, true, true]),
    ([true, true, false], [false, true, true]));
  assert_eq(collect_actor_credits(pending, [true, true, true],
    [true, true, true], [true, true, true]),
    ([false, true, false], [false, true, false]));
}

// Updated queue metadata and at most one reserved admission, before its RAM write.
pub struct AdmissionResult<ACTOR_COUNT: u32, PRODUCER_COUNT: u32, DEPTH: u32> {
  pending_valid: u1[PRODUCER_COUNT],
  occupied: u8[ACTOR_COUNT],
  order: u8[DEPTH][ACTOR_COUNT],
  mail_candidates: u1[ACTOR_COUNT],
  admission: Admission,
  cursor: u32,
}

// Reserve at most one eligible producer, starting at cursor and wrapping.
// Inputs include any retired activation's updates. Exclude the actor being
// issued and a just-failed actor; other destinations can still be admitted.
// A rejected request stays pending and leaves metadata and cursor unchanged.
pub fn reserve_admission<ACTOR_COUNT: u32, PRODUCER_COUNT: u32, DEPTH: u32>(
    occupied: u8[ACTOR_COUNT],
    order: u8[DEPTH][ACTOR_COUNT],
    mail_candidates: u1[ACTOR_COUNT],
    cursor: u32,
    pending: ScheduledRequest[PRODUCER_COUNT],
    pending_valid: u1[PRODUCER_COUNT],
    excluded_valid: u1,
    excluded_slot: u32,
    failed_valid: u1,
    failed_slot: u32) ->
    AdmissionResult<ACTOR_COUNT, PRODUCER_COUNT, DEPTH> {
  let (after_found, after_producer, before_found, before_producer) =
      unroll_for! (candidate, acc):
          (u32, (u1, u32, u1, u32)) in u32:0..PRODUCER_COUNT {
    let request = pending[candidate];
    let slot = request.slot;
    // Boolean operators are eager in DSLX; guard the array access itself.
    let has_capacity = if slot < ACTOR_COUNT {
      occupied[slot] as u32 < DEPTH
    } else {
      false
    };
    let eligible = pending_valid[candidate] && !request.credit &&
      has_capacity &&
      (!excluded_valid || slot != excluded_slot) &&
      (!failed_valid || slot != failed_slot);
    let take_after = !acc.0 &&
      candidate >= cursor && eligible;
    let take_before = !acc.2 &&
      candidate < cursor && eligible;
    (
      acc.0 || take_after,
      if take_after { candidate } else { acc.1 },
      acc.2 || take_before,
      if take_before { candidate } else { acc.3 }
    )
  }((u1:0, u32:0, u1:0, u32:0));
  let found = after_found || before_found;
  let producer = if after_found {
    after_producer
  } else {
    before_producer
  };
  let request = pending[producer];
  let slot = if request.slot < ACTOR_COUNT {
    request.slot
  } else {
    u32:0
  };
  let physical = free_index(order[slot], occupied[slot]);
  let old_count = occupied[slot];
  let occupied = if found {
    update(occupied, slot, old_count + u8:1)
  } else {
    occupied
  };
  let order = if found {
    let row = update(order[slot], old_count as u32, physical);
    update(order, slot, row)
  } else {
    order
  };
  let mail_candidates = if found {
    update(mail_candidates, slot, u1:1)
  } else {
    mail_candidates
  };
  let remaining = if found {
    update(pending_valid, producer, u1:0)
  } else {
    pending_valid
  };
  let cursor = if found {
    if producer + u32:1 == PRODUCER_COUNT {
      u32:0
    } else {
      producer + u32:1
    }
  } else {
    cursor
  };
  AdmissionResult<ACTOR_COUNT, PRODUCER_COUNT, DEPTH> {
    pending_valid: remaining,
    occupied,
    order,
    mail_candidates,
    admission: Admission {
      valid: found,
      producer,
      slot,
      physical,
    },
    cursor,
  }
}


// A transient projection of scheduler metadata for the retirement transition.
pub struct Metadata<ACTOR_COUNT: u32, DEPTH: u32> {
  occupied: u8[ACTOR_COUNT],
  order: u8[DEPTH][ACTOR_COUNT],
  postponed: u1[DEPTH][ACTOR_COUNT],
  mail_candidates: u1[ACTOR_COUNT],
  entry_probes: u1[ACTOR_COUNT],
  egress_waiters: u1[ACTOR_COUNT],
}

// The actor wrapper resolves its directive to mutually exclusive consume and
// postpone flags. Queue indices identify that completed activation's message.
pub struct Retirement {
  valid: u1,
  consume: u1,
  postpone: u1,
  phase_boundary: u1,
  failed: u1,
  enter_pending: u1,
  egress_blocked: u1,
}

// Apply a completed activation's consumption, postponement and readiness changes.
// A phase boundary clears postponement; failure clears the actor's ready flags.
// Valid outcomes require an in-range actor and valid selected message indices
// when consuming/postponing. An invalid outcome leaves metadata untouched.
pub fn retire<ACTOR_COUNT: u32, DEPTH: u32>(
    metadata: Metadata<ACTOR_COUNT, DEPTH>, slot: u32,
    order_index: u8, mailbox_index: u8, outcome: Retirement)
    -> Metadata<ACTOR_COUNT, DEPTH> {
  if !outcome.valid { metadata } else {
    let old_count = metadata.occupied[slot];
    let occupied = if outcome.consume {
      update(metadata.occupied, slot, old_count - u8:1)
    } else { metadata.occupied };
    let order = if outcome.consume {
      update(metadata.order, slot,
        compact_order(metadata.order[slot], order_index, old_count))
    } else { metadata.order };
    // A phase boundary clears every postponed message, including the selected
    // one. Otherwise only an explicit postponement changes the bitmap.
    let postponed_row = if outcome.phase_boundary {
      zero!<u1[DEPTH]>()
    } else if outcome.postpone {
      update(metadata.postponed[slot], mailbox_index as u32, u1:1)
    } else { metadata.postponed[slot] };
    let postponed = update(metadata.postponed, slot, postponed_row);
    let (mail_remaining, _, _) = select(order[slot], occupied[slot], postponed_row);
    Metadata<ACTOR_COUNT, DEPTH> {
      occupied,
      order,
      postponed,
      mail_candidates: update(metadata.mail_candidates, slot,
        mail_remaining && !outcome.failed),
      entry_probes: update(metadata.entry_probes, slot,
        outcome.enter_pending && !outcome.egress_blocked && !outcome.failed),
      egress_waiters: update(metadata.egress_waiters, slot,
        outcome.enter_pending && outcome.egress_blocked && !outcome.failed),
    }
  }
}

// RAM request rows must preserve actor ownership and the entire frame.
#[test]
fn rows_are_slot_major_and_hold_one_frame_test() {
  let frame = axis::pack(u8:13, u32:0x12345678);
  assert_eq(address(u32:3, u8:2, u32:5), u32:17);
  assert_eq(read(u32:3, u8:2, u32:5), bram::read(u32:17));
  assert_eq(
    write(u32:3, u8:2, u32:5, frame),
    bram::write(u32:17, axis::bits_from_frame(frame)));
}

// Postponement skips messages without reordering the remaining candidates.
#[test]
fn selection_preserves_queue_order_across_postponement_test() {
  let order = [u8:2, u8:0, u8:3, u8:1];
  assert_eq(select(order, u8:3, [false, false, false, false]),
            (true, u8:0, u8:2));
  assert_eq(select(order, u8:3, [false, false, true, false]),
            (true, u8:1, u8:0));
  assert_eq(select(order, u8:3, [true, false, true, false]),
            (true, u8:2, u8:3));
  // Physical slot one is unpostponed but outside the occupied prefix.
  assert_eq(select(order, u8:3, [true, false, true, true]),
            (false, u8:0, u8:0));
  assert_eq(select(order, u8:0, [false, false, false, false]),
            (false, u8:0, u8:0));
  // A phase boundary clears postponement and replays the oldest message.
  assert_eq(select(order, u8:3, zero!<bool[4]>()),
            (true, u8:0, u8:2));
}

// Reusing freed physical storage must append at the logical tail.
#[test]
fn consumption_reuses_physical_storage_at_queue_tail_test() {
  let order = [u8:2, u8:0, u8:3, u8:1];
  assert_eq(compact_order(order, u8:0, u8:4), [u8:0, u8:3, u8:1, u8:0]);
  assert_eq(compact_order(order, u8:3, u8:4), [u8:2, u8:0, u8:3, u8:0]);
  let compacted = compact_order(order, u8:1, u8:4);
  assert_eq(compacted, [u8:2, u8:3, u8:1, u8:0]);
  let request = ScheduledRequest { slot: u32:0, ..zero!<ScheduledRequest>() };
  let admitted = reserve_admission(
    [u8:3], [compacted], [true], u32:0, [request], [true],
    false, u32:0, false, u32:0);
  assert_eq(admitted.admission,
            Admission { valid: true, producer: u32:0, slot: u32:0, physical: u8:0 });
  assert_eq(admitted.occupied, [u8:4]);
  assert_eq(admitted.order, [[u8:2, u8:3, u8:1, u8:0]]);
  assert_eq(admitted.pending_valid, [false]);
  assert_eq(admitted.cursor, u32:0);
}

// Only eligible messages may reserve capacity; rejection must preserve metadata.
#[test]
fn admission_skips_full_excluded_failed_invalid_and_credit_requests_test() {
  let message = zero!<ScheduledRequest>();
  let pending = [
    ScheduledRequest { slot: u32:0, ..message },
    ScheduledRequest { slot: u32:1, ..message },
    ScheduledRequest { slot: u32:2, ..message },
    ScheduledRequest { slot: u32:99, ..message },
    ScheduledRequest { slot: u32:3, credit: true, ..message },
    ScheduledRequest { slot: u32:3, ..message },
  ];
  let occupied = [u8:2, u8:1, u8:0, u8:0];
  let order = [[u8:1, u8:0], [u8:0, u8:0], [u8:0, u8:0], [u8:0, u8:0]];
  let candidates = [true, true, false, false];
  let admitted = reserve_admission(
    occupied, order, candidates, u32:1, pending, [true, true, true, true, true, true],
    true, u32:1, true, u32:2);
  assert_eq(admitted.admission,
            Admission { valid: true, producer: u32:5, slot: u32:3, physical: u8:0 });
  assert_eq(admitted.occupied, [u8:2, u8:1, u8:0, u8:1]);
  assert_eq(admitted.order, order);
  assert_eq(admitted.mail_candidates, [true, true, false, true]);
  assert_eq(admitted.pending_valid, [true, true, true, true, true, false]);
  assert_eq(admitted.cursor, u32:0);
  // With the only admissible producer absent, even invalid pending addresses
  // must leave every piece of queue metadata untouched.
  let rejected = reserve_admission(
    occupied, order, candidates, u32:1, pending, admitted.pending_valid,
    true, u32:1, true, u32:2);
  assert_eq(rejected.admission.valid, false);
  assert_eq(rejected.occupied, occupied);
  assert_eq(rejected.order, order);
  assert_eq(rejected.mail_candidates, candidates);
  assert_eq(rejected.pending_valid, admitted.pending_valid);
  assert_eq(rejected.cursor, u32:1);
}

// A single-slot mailbox waits for consumption before admitting the next producer.
#[test]
fn admission_round_robins_and_waits_for_single_slot_retirement_test() {
  let request = zero!<ScheduledRequest>();
  let pending = [request, request, request];
  let first = reserve_admission(
    [u8:0], [[u8:0]], [false], u32:2, pending, [true, true, true],
    false, u32:0, false, u32:0);
  assert_eq(first.admission.producer, u32:2);
  assert_eq(first.cursor, u32:0);
  assert_eq(first.occupied, [u8:1]);
  assert_eq(first.mail_candidates, [true]);
  let full = reserve_admission(
    first.occupied, first.order, first.mail_candidates, first.cursor,
    pending, first.pending_valid, false, u32:0, false, u32:0);
  assert_eq(full.admission.valid, false);
  assert_eq(full.pending_valid, [true, true, false]);
  assert_eq(full.occupied, first.occupied);
  assert_eq(full.order, first.order);
  assert_eq(full.mail_candidates, first.mail_candidates);
  assert_eq(full.cursor, first.cursor);
  let retired = compact_order(first.order[u32:0], u8:0, u8:1);
  let next = reserve_admission(
    [u8:0], [retired], [false], full.cursor, pending, full.pending_valid,
    false, u32:0, false, u32:0);
  assert_eq(next.admission.valid, true);
  assert_eq(next.admission.producer, u32:0);
  assert_eq(next.cursor, u32:1);
  assert_eq(next.pending_valid, [false, true, false]);
  // Search wraps as well as the cursor: only a producer before cursor is ready.
  let wrapped = reserve_admission(
    [u8:0], [[u8:0]], [false], u32:1, pending, [true, false, false],
    false, u32:0, false, u32:0);
  assert_eq(wrapped.admission.valid, true);
  assert_eq(wrapped.admission.producer, u32:0);
  assert_eq(wrapped.cursor, u32:1);
}

// Collect one registered credit while retaining messages and newly captured work.
#[test]
fn credit_collection_releases_one_batch_without_consuming_messages_test() {
  let request = zero!<ScheduledRequest>();
  let credit = ScheduledRequest { credit: true, ..request };
  let pending = [credit, request, credit];
  assert_eq(collect_credit(pending, [false, true, false], [false, true, false], true),
            ([false, true, false], true));
  // Newly captured credits remain pending until the next iteration.
  assert_eq(collect_credit(pending, [false, false, false], [true, true, true], true),
    ([true, true, true], true));
  let (remaining, busy) = collect_credit(pending, [true, true, true], [true, true, true], true);
  assert_eq((remaining, busy), ([false, true, true], false));
  assert_eq(collect_credit(pending, remaining, remaining, busy),
            ([false, true, false], false));
}

// Consumption and a phase transition must preserve all remaining message order.
#[test]
fn retirement_preserves_queue_order_across_a_phase_boundary_test() {
  let metadata = Metadata<u32:2, u32:3> {
    occupied: [u8:3, u8:1],
    order: [[u8:2, u8:0, u8:1], [u8:1, u8:0, u8:0]],
    postponed: [[false, false, true], [false, false, false]],
    mail_candidates: [true, true],
    ..zero!<Metadata<u32:2, u32:3>>()
  };
  let retired = retire(metadata, u32:0, u8:1, u8:0, Retirement {
    valid: true, consume: true, phase_boundary: true, ..zero!<Retirement>() });
  assert_eq(retired.occupied, [u8:2, u8:1]);
  assert_eq(retired.order, [[u8:2, u8:1, u8:0], metadata.order[u32:1]]);
  assert_eq(retired.postponed, zero!<u1[3][2]>());
  assert_eq(retired.mail_candidates, [true, true]);
  assert_eq(select(retired.order[u32:0], u8:2, retired.postponed[u32:0]),
    (true, u8:0, u8:2));
}

// Entry credit and postponement must update readiness in the same transition.
#[test]
fn postponement_and_entry_credit_update_candidates_together_test() {
  let metadata = Metadata<u32:1, u32:2> {
    occupied: [u8:1], order: [[u8:1, u8:0]], mail_candidates: [true],
    ..zero!<Metadata<u32:1, u32:2>>()
  };
  let postponed = retire(metadata, u32:0, u8:0, u8:1, Retirement {
    valid: true, postpone: true, enter_pending: true, egress_blocked: true,
    ..zero!<Retirement>() });
  assert_eq(postponed.occupied, metadata.occupied);
  assert_eq(postponed.order, metadata.order);
  assert_eq(postponed.postponed, [[false, true]]);
  assert_eq(postponed.mail_candidates, [false]);
  assert_eq(postponed.entry_probes, [false]);
  assert_eq(postponed.egress_waiters, [true]);
  let resumed = retire(postponed, u32:0, u8:0, u8:1, Retirement {
    valid: true, phase_boundary: true, enter_pending: true, ..zero!<Retirement>() });
  assert_eq(resumed.postponed, [[false, false]]);
  assert_eq(resumed.mail_candidates, [true]);
  assert_eq(resumed.entry_probes, [true]);
  assert_eq(resumed.egress_waiters, [false]);
}

// Failure clears readiness; absent retirement cannot touch any metadata.
#[test]
fn failed_or_absent_retirements_cannot_reactivate_actors_test() {
  let metadata = Metadata<u32:1, u32:1> {
    occupied: [u8:1], mail_candidates: [true], entry_probes: [true],
    egress_waiters: [true], ..zero!<Metadata<u32:1, u32:1>>() };
  assert_eq(retire(metadata, u32:99, u8:99, u8:99, zero!<Retirement>()), metadata);
  let failed = retire(metadata, u32:0, u8:0, u8:0, Retirement {
    valid: true, failed: true, enter_pending: true, egress_blocked: true,
    ..zero!<Retirement>() });
  assert_eq(failed.mail_candidates, [false]);
  assert_eq(failed.entry_probes, [false]);
  assert_eq(failed.egress_waiters, [false]);
  assert_eq(failed.occupied, metadata.occupied);
  assert_eq(failed.order, metadata.order);
}

// Connect one independently owned producer endpoint to the scheduler array.
// Backpressure affects only this producer; credits must use dedicated relays.
pub proc RequestRelay {
  input: chan<ScheduledRequest> in;
  output: chan<ScheduledRequest> out;
  // Neither endpoint may have another writer/reader respectively.
  config(input: chan<ScheduledRequest> in, output: chan<ScheduledRequest> out) {
    (input, output)
  }
  // Hold no application state.
  init { () }
  // Preserve each request or credit until the scheduler accepts it.
  next(state: ()) {
    let (tok, request) = recv(join(), input);
    let _sent = send(tok, output, request);
    state
  }
}
