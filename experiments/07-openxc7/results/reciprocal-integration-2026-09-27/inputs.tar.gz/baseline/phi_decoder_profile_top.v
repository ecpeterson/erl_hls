// Decoder-only phi topology with scheduler-owned 1R1W RAMs. This shell is
// rendered by phi_decoder_profile_top_v from the selected physical profile.
module phi_decoder_profile_top (
    input  wire         aclk,
    input  wire         aresetn,

    output wire [127:0] x_decoder_event,
    output wire         x_decoder_event_valid,
    input  wire         x_decoder_event_ready,

    output wire [127:0] z_decoder_event,
    output wire         z_decoder_event_valid,
    input  wire         z_decoder_event_ready
);
    wire [31:0] scheduler_0_state_rd_addr;
    wire [31:0] scheduler_0_state_wr_addr;
    wire [224:0] scheduler_0_state_wr_data;
    wire scheduler_0_state_wr_en;
    wire scheduler_0_state_rd_en;
    wire [224:0] scheduler_0_state_rd_data;
    wire [31:0] scheduler_0_mailbox_rd_addr;
    wire [31:0] scheduler_0_mailbox_wr_addr;
    wire [127:0] scheduler_0_mailbox_wr_data;
    wire scheduler_0_mailbox_wr_en;
    wire scheduler_0_mailbox_rd_en;
    wire [127:0] scheduler_0_mailbox_rd_data;

    wire [31:0] scheduler_1_state_rd_addr;
    wire [31:0] scheduler_1_state_wr_addr;
    wire [224:0] scheduler_1_state_wr_data;
    wire scheduler_1_state_wr_en;
    wire scheduler_1_state_rd_en;
    wire [224:0] scheduler_1_state_rd_data;
    wire [31:0] scheduler_1_mailbox_rd_addr;
    wire [31:0] scheduler_1_mailbox_wr_addr;
    wire [127:0] scheduler_1_mailbox_wr_data;
    wire scheduler_1_mailbox_wr_en;
    wire scheduler_1_mailbox_rd_en;
    wire [127:0] scheduler_1_mailbox_rd_data;

    wire [31:0] scheduler_2_state_rd_addr;
    wire [31:0] scheduler_2_state_wr_addr;
    wire [539:0] scheduler_2_state_wr_data;
    wire scheduler_2_state_wr_en;
    wire scheduler_2_state_rd_en;
    wire [539:0] scheduler_2_state_rd_data;
    wire [31:0] scheduler_2_mailbox_rd_addr;
    wire [31:0] scheduler_2_mailbox_wr_addr;
    wire [127:0] scheduler_2_mailbox_wr_data;
    wire scheduler_2_mailbox_wr_en;
    wire scheduler_2_mailbox_rd_en;
    wire [127:0] scheduler_2_mailbox_rd_data;

    wire [31:0] scheduler_3_state_rd_addr;
    wire [31:0] scheduler_3_state_wr_addr;
    wire [539:0] scheduler_3_state_wr_data;
    wire scheduler_3_state_wr_en;
    wire scheduler_3_state_rd_en;
    wire [539:0] scheduler_3_state_rd_data;
    wire [31:0] scheduler_3_mailbox_rd_addr;
    wire [31:0] scheduler_3_mailbox_wr_addr;
    wire [127:0] scheduler_3_mailbox_wr_data;
    wire scheduler_3_mailbox_wr_en;
    wire scheduler_3_mailbox_rd_en;
    wire [127:0] scheduler_3_mailbox_rd_data;


    wire [31:0] profile_source_state_reads = {31'd0, scheduler_0_state_rd_en} + {31'd0, scheduler_1_state_rd_en};
    wire [31:0] profile_source_mailbox_reads = {31'd0, scheduler_0_mailbox_rd_en} + {31'd0, scheduler_1_mailbox_rd_en};
    wire [31:0] profile_phi_state_reads = {31'd0, scheduler_2_state_rd_en} + {31'd0, scheduler_3_state_rd_en};
    wire [31:0] profile_phi_mailbox_reads = {31'd0, scheduler_2_mailbox_rd_en} + {31'd0, scheduler_3_mailbox_rd_en};


    __phi_decoder_profile_topology__Top_0_next application (
        .clk(aclk),
        .reset(!aresetn),
        ._x_decoder_events_out(x_decoder_event),
        ._x_decoder_events_out_vld(x_decoder_event_valid),
        ._x_decoder_events_out_rdy(x_decoder_event_ready),
        ._z_decoder_events_out(z_decoder_event),
        ._z_decoder_events_out_vld(z_decoder_event_valid),
        ._z_decoder_events_out_rdy(z_decoder_event_ready),
        .scheduler_0_state_rd_addr(scheduler_0_state_rd_addr),
        .scheduler_0_state_wr_addr(scheduler_0_state_wr_addr),
        .scheduler_0_state_wr_data(scheduler_0_state_wr_data),
        .scheduler_0_state_wr_en(scheduler_0_state_wr_en),
        .scheduler_0_state_rd_en(scheduler_0_state_rd_en),
        .scheduler_0_state_rd_data(scheduler_0_state_rd_data),
        .scheduler_0_mailbox_rd_addr(scheduler_0_mailbox_rd_addr),
        .scheduler_0_mailbox_wr_addr(scheduler_0_mailbox_wr_addr),
        .scheduler_0_mailbox_wr_data(scheduler_0_mailbox_wr_data),
        .scheduler_0_mailbox_wr_en(scheduler_0_mailbox_wr_en),
        .scheduler_0_mailbox_rd_en(scheduler_0_mailbox_rd_en),
        .scheduler_0_mailbox_rd_data(scheduler_0_mailbox_rd_data),
        .scheduler_1_state_rd_addr(scheduler_1_state_rd_addr),
        .scheduler_1_state_wr_addr(scheduler_1_state_wr_addr),
        .scheduler_1_state_wr_data(scheduler_1_state_wr_data),
        .scheduler_1_state_wr_en(scheduler_1_state_wr_en),
        .scheduler_1_state_rd_en(scheduler_1_state_rd_en),
        .scheduler_1_state_rd_data(scheduler_1_state_rd_data),
        .scheduler_1_mailbox_rd_addr(scheduler_1_mailbox_rd_addr),
        .scheduler_1_mailbox_wr_addr(scheduler_1_mailbox_wr_addr),
        .scheduler_1_mailbox_wr_data(scheduler_1_mailbox_wr_data),
        .scheduler_1_mailbox_wr_en(scheduler_1_mailbox_wr_en),
        .scheduler_1_mailbox_rd_en(scheduler_1_mailbox_rd_en),
        .scheduler_1_mailbox_rd_data(scheduler_1_mailbox_rd_data),
        .scheduler_2_state_rd_addr(scheduler_2_state_rd_addr),
        .scheduler_2_state_wr_addr(scheduler_2_state_wr_addr),
        .scheduler_2_state_wr_data(scheduler_2_state_wr_data),
        .scheduler_2_state_wr_en(scheduler_2_state_wr_en),
        .scheduler_2_state_rd_en(scheduler_2_state_rd_en),
        .scheduler_2_state_rd_data(scheduler_2_state_rd_data),
        .scheduler_2_mailbox_rd_addr(scheduler_2_mailbox_rd_addr),
        .scheduler_2_mailbox_wr_addr(scheduler_2_mailbox_wr_addr),
        .scheduler_2_mailbox_wr_data(scheduler_2_mailbox_wr_data),
        .scheduler_2_mailbox_wr_en(scheduler_2_mailbox_wr_en),
        .scheduler_2_mailbox_rd_en(scheduler_2_mailbox_rd_en),
        .scheduler_2_mailbox_rd_data(scheduler_2_mailbox_rd_data),
        .scheduler_3_state_rd_addr(scheduler_3_state_rd_addr),
        .scheduler_3_state_wr_addr(scheduler_3_state_wr_addr),
        .scheduler_3_state_wr_data(scheduler_3_state_wr_data),
        .scheduler_3_state_wr_en(scheduler_3_state_wr_en),
        .scheduler_3_state_rd_en(scheduler_3_state_rd_en),
        .scheduler_3_state_rd_data(scheduler_3_state_rd_data),
        .scheduler_3_mailbox_rd_addr(scheduler_3_mailbox_rd_addr),
        .scheduler_3_mailbox_wr_addr(scheduler_3_mailbox_wr_addr),
        .scheduler_3_mailbox_wr_data(scheduler_3_mailbox_wr_data),
        .scheduler_3_mailbox_wr_en(scheduler_3_mailbox_wr_en),
        .scheduler_3_mailbox_rd_en(scheduler_3_mailbox_rd_en),
        .scheduler_3_mailbox_rd_data(scheduler_3_mailbox_rd_data)
    );

    hls_1r1w_ram #(.WIDTH(225), .ADDRESS_WIDTH(1)) scheduler_0_state (
        .clk(aclk),
        .rd_addr(scheduler_0_state_rd_addr[0:0]),
        .wr_addr(scheduler_0_state_wr_addr[0:0]),
        .wr_data(scheduler_0_state_wr_data),
        .wr_en(scheduler_0_state_wr_en),
        .rd_en(scheduler_0_state_rd_en),
        .rd_data(scheduler_0_state_rd_data)
    );

    hls_1r1w_ram #(.WIDTH(128), .ADDRESS_WIDTH(1)) scheduler_0_mailbox (
        .clk(aclk),
        .rd_addr(scheduler_0_mailbox_rd_addr[0:0]),
        .wr_addr(scheduler_0_mailbox_wr_addr[0:0]),
        .wr_data(scheduler_0_mailbox_wr_data),
        .wr_en(scheduler_0_mailbox_wr_en),
        .rd_en(scheduler_0_mailbox_rd_en),
        .rd_data(scheduler_0_mailbox_rd_data)
    );

    hls_1r1w_ram #(.WIDTH(225), .ADDRESS_WIDTH(1)) scheduler_1_state (
        .clk(aclk),
        .rd_addr(scheduler_1_state_rd_addr[0:0]),
        .wr_addr(scheduler_1_state_wr_addr[0:0]),
        .wr_data(scheduler_1_state_wr_data),
        .wr_en(scheduler_1_state_wr_en),
        .rd_en(scheduler_1_state_rd_en),
        .rd_data(scheduler_1_state_rd_data)
    );

    hls_1r1w_ram #(.WIDTH(128), .ADDRESS_WIDTH(1)) scheduler_1_mailbox (
        .clk(aclk),
        .rd_addr(scheduler_1_mailbox_rd_addr[0:0]),
        .wr_addr(scheduler_1_mailbox_wr_addr[0:0]),
        .wr_data(scheduler_1_mailbox_wr_data),
        .wr_en(scheduler_1_mailbox_wr_en),
        .rd_en(scheduler_1_mailbox_rd_en),
        .rd_data(scheduler_1_mailbox_rd_data)
    );

    hls_1r1w_ram #(.WIDTH(540), .ADDRESS_WIDTH(1)) scheduler_2_state (
        .clk(aclk),
        .rd_addr(scheduler_2_state_rd_addr[0:0]),
        .wr_addr(scheduler_2_state_wr_addr[0:0]),
        .wr_data(scheduler_2_state_wr_data),
        .wr_en(scheduler_2_state_wr_en),
        .rd_en(scheduler_2_state_rd_en),
        .rd_data(scheduler_2_state_rd_data)
    );

    hls_1r1w_ram #(.WIDTH(128), .ADDRESS_WIDTH(4)) scheduler_2_mailbox (
        .clk(aclk),
        .rd_addr(scheduler_2_mailbox_rd_addr[3:0]),
        .wr_addr(scheduler_2_mailbox_wr_addr[3:0]),
        .wr_data(scheduler_2_mailbox_wr_data),
        .wr_en(scheduler_2_mailbox_wr_en),
        .rd_en(scheduler_2_mailbox_rd_en),
        .rd_data(scheduler_2_mailbox_rd_data)
    );

    hls_1r1w_ram #(.WIDTH(540), .ADDRESS_WIDTH(1)) scheduler_3_state (
        .clk(aclk),
        .rd_addr(scheduler_3_state_rd_addr[0:0]),
        .wr_addr(scheduler_3_state_wr_addr[0:0]),
        .wr_data(scheduler_3_state_wr_data),
        .wr_en(scheduler_3_state_wr_en),
        .rd_en(scheduler_3_state_rd_en),
        .rd_data(scheduler_3_state_rd_data)
    );

    hls_1r1w_ram #(.WIDTH(128), .ADDRESS_WIDTH(4)) scheduler_3_mailbox (
        .clk(aclk),
        .rd_addr(scheduler_3_mailbox_rd_addr[3:0]),
        .wr_addr(scheduler_3_mailbox_wr_addr[3:0]),
        .wr_data(scheduler_3_mailbox_wr_data),
        .wr_en(scheduler_3_mailbox_wr_en),
        .rd_en(scheduler_3_mailbox_rd_en),
        .rd_data(scheduler_3_mailbox_rd_data)
    );


endmodule
